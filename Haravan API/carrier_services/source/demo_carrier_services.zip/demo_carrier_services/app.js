var express = require('express');
var bodyParser = require('body-parser');
var crypto = require('crypto');
var app = express();
var path = require('path');
var HaravanValidate = require(path.resolve('./haravan-validate'));
let app_id = '267f661fa6eecd88996fcc438203d38b';

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// parse application/json
var haravanValidate = new HaravanValidate(app_id);
app.use(haravanValidate);
app.use(bodyParser.json());

app.get('/', function (req, res) {
  res.send('already to use');
});

//----------------------------Authenticate-----------------------------------//
function verify_carrier(req, res, next) {
  let signature = req.headers['x-haravan-hmac-sha256'] || '';


  if (!signature) {
    return res.sendStatus(401);
  }

  if (!req.fromHaravan(app_id)) {
    return res.sendStatus(401);
  }

  next();
};
//--------------------------------------------------------------------------


//request get shipping rates.
app.post('/get_shipping_rates_url' ,verify_carrier,  function (req, res) {
  let list_shipping_rate = {
    error: false,
    message: null,
    data : {
      rates: [
        {
          service_id: 123456,
          service_name: 'Fast shipping',
          service_code: 'fast',
          currency: 'vnd',
          total_price: 10000,
          phone_required: true,
          min_delivery_date: new Date(),
          max_delivery_date: new Date(),
          description: ''
        },
        {
          service_id: 456789,
          service_name: 'Save shipping',
          service_code: 'save',
          currency: 'vnd',
          total_price: 5000,
          phone_required: false,
          min_delivery_date: null,
          max_delivery_date: null,
          description: ''
        }
      ]
    }
  };
  res.json(list_shipping_rate);
});


////request create order shipping.
app.post('/create_order_url', verify_carrier,  function (req, res) {
  let body = req.body;
  let tracking_url = 'https://abc.com/tracking_url/';
  let tracking_number = Math.floor(Math.random()*1000000);
  // let shipping_fee =
  let data_order = {
      'error': false,
      'message': '',
        'data': {
            "tracking_number": tracking_number,
                "shipping_fee": 5000,
                "tracking_url": tracking_url,
                "cod_amount": body.cod_amount ? body.cod_amount : 0
          }
      };
  res.json(data_order);
});

//request get order shipping detail.
app.post('/get_order_detail_url' ,  function (req, res) {
  let body = req.body;
  let tracking_url = 'https://abc.com/tracking_url/';
  let data_order = {
    'error': false,
    'message': '',
    'data': {
      tracking_number: body.tracking_number,
      shipping_fee: 5000,
      tracking_url: tracking_url,
      cod_amount: 5000,
      status: 'Delivered',
      cod_status: 'CODPaid'

    }
  };
  res.json(data_order);
});

//request cancel order shipping.
app.delete('/cancel_order_url',verify_carrier , function (req, res) {
  let body = req.body;
  let tracking_url = 'https://abc.com/tracking_url/';
  let data_order = {
    'error': false,
    'message': '',
    'data': {
      tracking_number: body.tracking_number,
      shipping_fee: 5000,
      tracking_url: tracking_url,
      cod_amount: 5000,
      status: 'Cancel'
    }
  };
  res.json(data_order);
});



app.listen(3000, function () {
  console.log('Example app listening on port 3000!');
});